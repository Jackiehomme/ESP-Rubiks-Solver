
#include "MovesCube.h"

bool Enable = true;
void initMovesCube(uint8_t pinServoA,uint8_t pinServoB, Motor* M1, Motor* M2, Motor* M3, Motor* M4){
    initStepper(M1, M2, M3, M4);
    initServo(pinServoA, pinServoB);
}
void TurnCube(uint8_t Sens){
    moveServo(SERVOA, S_OPEN);
    vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
    turnMultiple(90, Sens, &M2, &M4);
    vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
    moveServo(SERVOA, S_CLOSE);
    vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);

    moveServo(SERVOB, S_OPEN);
    vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
    turnMultiple(90, Sens, &M2, &M4);
    vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
    moveServo(SERVOB, S_CLOSE);
    vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
}

void TurnF(uint16_t degree, uint8_t sens){
    turn(degree, sens, &M1);
    vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
    if (degree == 90){
        moveServo(SERVOA, S_OPEN);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
        turn(degree, !sens, &M1);
        vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
        moveServo(SERVOA, S_CLOSE);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
    }
}

void TurnR(uint16_t degree, uint8_t sens){
    turn(degree, sens, &M2);
    vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
    if (degree == 90){
        moveServo(SERVOB, S_OPEN);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
        turn(degree, !sens, &M2);
        vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
        moveServo(SERVOB, S_CLOSE);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
    }
}
void TurnB(uint16_t degree, uint8_t sens){
    turn(degree, sens, &M3);
    vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
    if (degree == 90){
        moveServo(SERVOA, S_OPEN);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
        turn(degree, !sens, &M3);
        vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
        moveServo(SERVOA, S_CLOSE);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
    }
}
void TurnL(uint16_t degree, uint8_t sens){
    turn(degree, sens, &M4);
    vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
    if (degree == 90){
        moveServo(SERVOB, S_OPEN);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
        turn(degree, !sens, &M4);
        vTaskDelay(MOTOR_MS / portTICK_PERIOD_MS);
        moveServo(SERVOB, S_CLOSE);
        vTaskDelay(SERVO_MS / portTICK_PERIOD_MS);
    }
}