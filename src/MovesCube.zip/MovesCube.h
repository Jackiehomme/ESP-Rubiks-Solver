#ifndef MovesCube
#define MovesCube

#include "driver/gpio.h"
#include "Stepper.h"
#include "Servo.h"
// MOTOR 1
#define M1_STEP GPIO_NUM_19
#define M1_DIR GPIO_NUM_18
// MOTOR 2
#define M2_STEP GPIO_NUM_5
#define M2_DIR GPIO_NUM_17
// MOTOR 3
#define M3_STEP GPIO_NUM_16
#define M3_DIR GPIO_NUM_4
// MOTOR 4
#define M4_STEP GPIO_NUM_2
#define M4_DIR GPIO_NUM_15

#define EN_MOTOR GPIO_NUM_23

// HOME
#define HOME1 GPIO_NUM_34
#define HOME2 GPIO_NUM_35
#define HOME3 GPIO_NUM_32
#define HOME4 GPIO_NUM_33

// SERVO
#define SERVOA GPIO_NUM_13
#define SERVOB GPIO_NUM_14
#define S_OPEN 55
#define S_CLOSE -75

#define MOTOR_MS 10
#define SERVO_MS 500

#define ACCEL 200 // 200
#define SPEED 150 // 150

extern Motor M1;// = {HOME1, M1_STEP, M1_DIR, RPM_TO_RADpS(ACCEL), RPM_TO_RADpS(SPEED)};
extern Motor M2;// = {HOME2, M2_STEP, M2_DIR, RPM_TO_RADpS(ACCEL), RPM_TO_RADpS(SPEED)};
extern Motor M3;// = {HOME3, M3_STEP, M3_DIR, RPM_TO_RADpS(ACCEL), RPM_TO_RADpS(SPEED)};
extern Motor M4;// = {HOME4, M4_STEP, M4_DIR, RPM_TO_RADpS(ACCEL), RPM_TO_RADpS(SPEED)};

void initMovesCube(uint8_t pinServoA,uint8_t pinServoB, Motor* M1, Motor* M2, Motor* M3, Motor* M4);
void TurnCube(uint8_t Sens);
void TurnF(uint16_t degree, uint8_t sens);
void TurnR(uint16_t degree, uint8_t sens);
void TurnB(uint16_t degree, uint8_t sens);
void TurnL(uint16_t degree, uint8_t sens);

#endif